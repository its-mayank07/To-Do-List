import React from 'react'
// import noteContext from '../context/notes/NoteContext'
const About = () => {
  
  
  return (
    <div>this is about page</div>
  )
}

export default About